(function(module) {
  mifosX.models = _.extend(module, {
    email : "testshaik@gmail.com",
    url : "https://www.sandbox.paypal.com/cgi-bin/webscr"
  });
}(mifosX.models || {}));