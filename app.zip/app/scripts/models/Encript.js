(function(module) {
  mifosX.models = _.extend(module, {
	  encrptionKey : "Hugo Technologys" //key should be either 16 or 32 characters(even one space also taking as one character)	  
  });	 
}(mifosX.models || {}));
